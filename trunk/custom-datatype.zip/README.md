# Purpose

This WordPress plugin implements a proof of concept for creating custom post types within wp-admin

## Links

- [Registering Custom Post Types in the WordPress Admin](https://wordpress.com/blog/2024/04/15/custom-post-types-wordpress-admin/)
