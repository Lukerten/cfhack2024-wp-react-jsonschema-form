import SplitPane from './SplitPane';

import './index.scss';

export default SplitPane;
